 
var rt=document.querySelector(".l1")
var et=document.querySelector(".l2")
var result=document.querySelector(".up")

function resultfunction(){
   var t= Number(rt.value)
   var y=Number(et.value)
   var total=t+y
   result.textContent=total
}