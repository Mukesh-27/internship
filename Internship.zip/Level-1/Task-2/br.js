var fd=document.querySelector(".tr")
var ty=document.querySelector(".ji")
var gh=document.querySelector(".gr")
ty.addEventListener("click",function(){
    ty.style.backgroundColor = 'red';
    ty.style.color = 'black';
    

})
